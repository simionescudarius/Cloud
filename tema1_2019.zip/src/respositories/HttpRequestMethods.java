package respositories;

public enum HttpRequestMethods {
	GET, POST;
}
