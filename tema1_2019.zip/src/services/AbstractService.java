package services;

import org.apache.log4j.Logger;

import tema1.Server;

public abstract class AbstractService {
	public static String APY_KEY_FILE_PATH;
	protected static final Logger LOGGER = Logger.getLogger(Server.class);
}
